import React, {Component} from 'react'
import {Route, BrowserRouter, Link, Redirect, Switch} from 'react-router-dom'
import Login from './containers/Login.js';
import Register from './containers/Register.js';
import Home from './containers/Home.js';
// import { logout } from '../helpers/auth'
import {firebaseAuth} from './fireabaseGonfig.js'

function PrivateRoute({
	component: Component,
	authed,
	...rest
}) {
	console.log(2);
	return (
		<Route {...rest} render={(props) => authed === true
			? <Component {...props}/>
			: <Redirect to={{
				pathname: '/login',
				state: {
					from: props.location
				}
			}}/>}/>
	)
}

function PublicRoute({
	component: Component,
	authed,
	...rest
}) {
	return (
		<Route {...rest} render={(props) => authed === false
			? <Component {...props}/>
			: <Redirect to='/'/>}/>
	)
}

export default class App extends Component {
	state = {
		authed: false,
		loading: true
	}
	componentDidMount() {
		this.removeListener = firebaseAuth().onAuthStateChanged((user) => {
			console.log(user);
			if (user) {
				this.setState({authed: true, loading: false})
			} else {
				this.setState({authed: false, loading: false})
			}
		})
	}
	componentWillUnmount() {
		this.removeListener()
	}
	render() {
		return this.state.loading === true
			? <h1>Loading</h1>
			: (
				<BrowserRouter>
					<div>
						{/* <nav className="navbar navbar-default navbar-static-top">
							<div className="container">
								<div className="navbar-header">
									<Link to="/" className="navbar-brand">React Router + Firebase Auth</Link>
								</div>
								<ul className="nav navbar-nav pull-right">
									<li>
										<Link to="/" className="navbar-brand">Home</Link>
									</li>
									<li>
										<Link to="/register" className="navbar-brand">Registr</Link>
									</li>
								</ul>
							</div>
						</nav> */}
						{/* <div className="container"> */}
							{/* <div className="row"> */}
								<Switch>
									{/* <Route path='/' exact component={Home} /> */}
									<PrivateRoute authed={this.state.authed} exact path='/' component={Home}/>
									<PublicRoute authed={this.state.authed} path='/login' component={Login}/>
									<PublicRoute authed={this.state.authed} path='/register' component={Register}/>
									<Route render={() => <h3>No Match</h3>}/>
								</Switch>
							{/* </div> */}
						{/* </div> */}
					</div>
				</BrowserRouter>
			);
	}
}

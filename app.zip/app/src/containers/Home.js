import React from 'react';
// import styled from 'styled-components'
// import firebase from 'firebase';

export default class Home extends React.Component {

	//initial state
	constructor(props) {
		super(props)
		this.state = {
			data: 'initial'
		}
	}

	//Methods

	render() {
		//Properties

		//Style

		//Template
		return (
			<div>
				<p>HOMEEEE</p>
			</div>
		);
	}

}
